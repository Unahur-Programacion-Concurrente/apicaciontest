const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

// Configuración dinámica de CORS para aceptar múltiples orígenes
const allowedOrigins = ['http://localhost:3000', 'http://otraaplicacion-dev.eba-ndm2f8ty.us-east-1.elasticbeanstalk.com'];

app.use(cors({
    origin: function(origin, callback){
        // Permitir solicitudes sin 'origin' (como aplicaciones móviles o curl)
        if(!origin) return callback(null, true);
        if(allowedOrigins.indexOf(origin) === -1){
            var msg = 'La política de CORS para este sitio no permite el acceso desde el origen especificado.';
            return callback(new Error(msg), false);
        }
        return callback(null, true);
    }
}));

// Servir archivos estáticos (frontend)
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api', (req, res) => {
    res.json({ message: "Hola desde el backend!" });
});

const port = 3000;
app.listen(port, () => {
    console.log(`Servidor escuchando en http://localhost:3000`);
});
