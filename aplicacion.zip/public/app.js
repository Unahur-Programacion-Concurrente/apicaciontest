document.getElementById('fetchMessage').addEventListener('click', async () => {
//    const backendUrl = window.location.hostname.includes('localhost')
//        ? 'http://localhost:3000/api'
//        : 'http://otraaplicacion-dev.eba-ndm2f8ty.us-east-1.elasticbeanstalk.com/api';

    const backendUrl = window.location.hostname.includes('localhost')
       ? 'http://localhost:3000/api'
       : `http://${window.location.hostname}:3000/api`;
    const response = await fetch(backendUrl);
    const data = await response.json();
    document.getElementById('message').innerText = data.message;
});
document.getElementById('clearMessage').addEventListener('click', () => {
    document.getElementById('message').innerText = '';
});
