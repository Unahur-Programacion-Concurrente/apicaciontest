describe('Frontend Interaction Test', () => {
  beforeEach(() => {
      document.body.innerHTML = `
          <button id="fetchMessage">Obtener Mensaje</button>
          <button id="clearMessage">Limpiar Mensaje</button>
          <div id="message"></div>
      `; // Asegúrate de que todos los elementos necesarios estén presentes en el DOM

      global.fetch = jest.fn(() =>
          Promise.resolve({
              json: () => Promise.resolve({ message: 'Mensaje mockeado desde la API' }),
          })
      );

      // Requiere tu archivo app.js después de configurar el DOM para asegurarte de que los eventListeners se añadan correctamente
      require('../../public/app');
  });

  afterEach(() => {
      jest.resetAllMocks();
  });

  it('should update the message div with API response when button is clicked', async () => {
      // Simula el clic en el botón para obtener el mensaje
      document.getElementById('fetchMessage').click();

      await new Promise(process.nextTick); // Espera a que todas las promesas pendientes se resuelvan

      const messageDiv = document.getElementById('message');
      expect(messageDiv.innerText).toBe('Mensaje mockeado desde la API');
  });
});
