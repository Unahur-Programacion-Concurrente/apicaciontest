#!/bin/bash

# Definir las variables
APP_NAME="fullstack-app"
ZIP_NAME="${APP_NAME}.zip"
DEPLOY_DIR="/var/www/${APP_NAME}"

BACKEND_URL="http://$EC2_PUBLIC_IP/api"
BACKEND_PORT=3000

# Terminar cualquier proceso que esté utilizando el puerto BACKEND_PORT
sudo fuser -k $BACKEND_PORT/tcp

# Instalar Node.js y NPM si no están instalados
if ! command -v node &> /dev/null; then
    curl -sL https://rpm.nodesource.com/setup_14.x | sudo bash -
    sudo yum install -y nodejs
fi

# Instalar PM2 globalmente si no está instalado
if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
fi

 #Mover el .zip al directorio de despliegue y cambiar el propietario
 sudo mkdir -p ${DEPLOY_DIR}
 sudo chown -R $USER:$USER ${DEPLOY_DIR}
 sudo mv /tmp/${ZIP_NAME} ${DEPLOY_DIR}
 


# Ir al directorio de despliegue y descomprimir
cd ${DEPLOY_DIR}
sudo unzip -o ${ZIP_NAME}

pwd
ls -la

# Instalar dependencias del proyecto
npm install

# Usar PM2 para iniciar/reiniciar la aplicación
pm2 restart ${APP_NAME} || pm2 start index.js --name ${APP_NAME}

# Limpiar
sudo rm ${ZIP_NAME}

